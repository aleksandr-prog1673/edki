package com.exam.test_simulator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
