import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models/question.dart';
import 'services/exam_parser.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Перевіряємо, чи користувач вже був авторизований раніше
  SharedPreferences prefs = await SharedPreferences.getInstance();
  bool isLoggedIn = prefs.getBool('is_logged_in') ?? false;

  runApp(EDKISimulatorApp(isLoggedIn: isLoggedIn));
}

class EDKISimulatorApp extends StatelessWidget {
  final bool isLoggedIn;
  const EDKISimulatorApp({Key? key, required this.isLoggedIn}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Симулятор ЄДКІ: Ядерна енергетика',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: isLoggedIn ? const HomeScreen() : const AuthScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

// ==================== ЕКРАН АВТОРИЗАЦІЇ / РЕЄСТРАЦІЇ ====================
class AuthScreen extends StatefulWidget {
  const AuthScreen({Key? key}) : super(key: key);

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isRegistering = false;
  String? _errorMessage;
  bool _isLoading = false;

  // Симуляція відправки 4-значного коду на пошту
  void _submit() async {
    final email = _emailController.text.trim();
    final password = _passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      setState(() {
        _errorMessage = 'Будь ласка, заповніть пошту та пароль';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    // Імітація запиту на сервер / відправки листа на пошту
    await Future.delayed(const Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });

    if (_isRegistering) {
      // Генерація 4-значного коду
      String generatedCode = (1000 + Random().nextInt(9000)).toString();
      
      // У реальному продакшні тут викликається API для відправки листа через SMTP/SendGrid.
      // Для зручності тестування виводимо код у консоль або у повідомленні (у реалі користувач дивиться у свій Gmail).
      print('=== КОД ПІДТВЕРДЖЕННЯ ДЛЯ $email: $generatedCode ===');

      // Переходимо на екран введення 4-значного коду
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => VerificationScreen(
            email: email,
            expectedCode: generatedCode,
          ),
        ),
      );
    } else {
      // Звичайний вхід для вже зареєстрованого користувача
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('is_logged_in', true);
      await prefs.setString('user_email', email);

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => const HomeScreen(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF0A192F), Color(0xFF172A45), Color(0xFF303C55)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Card(
              elevation: 12,
              margin: const EdgeInsets.all(24),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              child: Padding(
                padding: const EdgeInsets.all(32.0),
                child: SizedBox(
                  width: 420,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(
                          AppDataStorage.headerImageUrl,
                          height: 140,
                          width: double.infinity,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Container(
                            height: 140,
                            color: Colors.blue.shade900,
                            child: const Icon(Icons.bolt, size: 64, color: Colors.cyanAccent),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        _isRegistering ? 'Реєстрація студента' : 'Вхід у систему ЄДКІ',
                        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'Спеціальність 143: Ядерна енергетика',
                        style: TextStyle(color: Colors.grey, fontSize: 13),
                      ),
                      const SizedBox(height: 24),
                      TextField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(
                          labelText: 'Електронна пошта (Gmail тощо)',
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.email),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextField(
                        controller: _passwordController,
                        obscureText: true,
                        decoration: InputDecoration(
                          labelText: 'Пароль',
                          border: const OutlineInputBorder(),
                          prefixIcon: const Icon(Icons.lock),
                          errorText: _errorMessage,
                        ),
                      ),
                      const SizedBox(height: 24),
                      _isLoading
                          ? const CircularProgressIndicator()
                          : ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                minimumSize: const Size.fromHeight(50),
                                backgroundColor: Colors.blue.shade800,
                                foregroundColor: Colors.white,
                              ),
                              onPressed: _submit,
                              child: Text(
                                _isRegistering ? 'Далі (Отримати код на пошту)' : 'Увійти',
                                style: const TextStyle(fontSize: 16),
                              ),
                            ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () {
                          setState(() {
                            _isRegistering = !_isRegistering;
                            _errorMessage = null;
                          });
                        },
                        child: Text(
                          _isRegistering
                              ? 'Вже маєте акаунт? Увійти'
                              : 'Немає акаунта? Зареєструватися',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ==================== ЕКРАН ВВЕДЕННЯ 4-ЗНАЧНОГО КОДУ ====================
class VerificationScreen extends StatefulWidget {
  final String email;
  final String expectedCode;

  const VerificationScreen({Key? key, required this.email, required this.expectedCode}) : super(key: key);

  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  final _codeController = TextEditingController();
  String? _errorText;

  void _verifyCode() async {
    String enteredCode = _codeController.text.trim();

    if (enteredCode == widget.expectedCode) {
      // Код підтверджено успішно! Зберігаємо стан входу
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setBool('is_logged_in', true);
      await prefs.setString('user_email', widget.email);

      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const HomeScreen()),
        (route) => false,
      );
    } else {
      setState(() {
        _errorText = 'Невірний код підтвердження. Спробуйте ще раз.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Підтвердження електронної пошти')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: SizedBox(
            width: 400,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.mark_email_read, size: 80, color: Colors.blue),
                const SizedBox(height: 20),
                const Text(
                  'Введіть 4-значний код',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  'Ми відправили код підтвердження на вашу пошту:\n${widget.email}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.grey),
                ),
                const SizedBox(height: 8),
                // Підказка для зручності тестування (у реальному додатку прибирається)
                Text(
                  '(Тестовий код: ${widget.expectedCode})',
                  style: const TextStyle(color: Colors.indigo, fontWeight: FontWeight.bold, fontSize: 13),
                ),
                const SizedBox(height: 24),
                TextField(
                  controller: _codeController,
                  keyboardType: TextInputType.number,
                  maxLength: 4,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 24, letterSpacing: 8, fontWeight: FontWeight.bold),
                  decoration: InputDecoration(
                    border: const OutlineInputBorder(),
                    hintText: '0000',
                    errorText: _errorText,
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size.fromHeight(50),
                    backgroundColor: Colors.green,
                    foregroundColor: Colors.white,
                  ),
                  onPressed: _verifyCode,
                  child: const Text('Підтвердити та увійти', style: TextStyle(fontSize: 16)),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ==================== ГЛОБАЛЬНІ ДАНІ ====================
class AppDataStorage {
  static String headerImageUrl = 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?auto=format&fit=crop&w=1000&q=80';
  
  static List<Map<String, dynamic>> disciplines = [
    {
      'title': 'Фізика ядерних реакторів та нейтронна кінетика',
      'subtitle': 'Тестування за розділом фізичних процесів у активній зоні',
      'icon': Icons.bolt,
      'color': Colors.orange,
      'questions': <Question>[
        Question(
          text: 'Який основний принцип роботи ядерного реактора на теплових нейтронах?',
          options: [
            'Поділ ядер урану-235 тепловими нейтронами',
            'Злиття ядер водню при високій температурі',
            'Гіперзвукове горіння палива',
            'Термоелектричне перетворення',
          ],
          correctAnswerIndex: 0,
          explanation: 'Реактори на теплових нейтронах використовують сповільнювачі для зниження енергії нейтронів.',
        ),
      ],
    },
    {
      'title': 'Ядерна та радіаційна безпека АЕС',
      'subtitle': 'Нормативи, правила експлуатації та захист середовища',
      'icon': Icons.security,
      'color': Colors.red,
      'questions': <Question>[],
    },
    {
      'title': 'Теплогідравліка та обладнання АЕС',
      'subtitle': 'Парові котли, турбіни, контури та гідравлічні процеси',
      'icon': Icons.waves,
      'color': Colors.blue,
      'questions': <Question>[],
    },
    {
      'title': 'Електротехнічні системи та генерація на АЕС',
      'subtitle': 'Системи електропостачання власних потреб та видачі потужності',
      'icon': Icons.power,
      'color': Colors.green,
      'questions': <Question>[],
    },
  ];
}

// ==================== ГОЛОВНЕ МЕНЮ ====================
class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  void _startTestForDiscipline(Map<String, dynamic> discipline) {
    List<Question> questions = discipline['questions'];
    if (questions.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Для дисципліни "${discipline['title']}" ще не завантажено питань! Завантажте через адмін-панель.')),
      );
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ActiveExamPage(
          disciplineTitle: discipline['title'],
          questions: questions,
        ),
      ),
    );
  }

  void _showAdminDialog() {
    final passwordController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Вхід до Адмін-панелі'),
        content: TextField(
          controller: passwordController,
          obscureText: true,
          decoration: const InputDecoration(
            labelText: 'Пароль адміністратора',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Скасувати'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.purple, foregroundColor: Colors.white),
            onPressed: () {
              if (passwordController.text == 'admin242029') {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AdminPanelScreen()),
                ).then((_) => setState(() {}));
              } else {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Невірний пароль адміністратора!')),
                );
              }
            },
            child: const Text('Увійти'),
          ),
        ],
      ),
    );
  }

  // Вихід з акаунта (очищення сесії)
  void _logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_logged_in', false);

    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const AuthScreen()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ЄДКІ: Ядерна енергетика — Дисципліни'),
        actions: [
          IconButton(
            icon: const Icon(Icons.admin_panel_settings),
            tooltip: 'Адмін-панель',
            onPressed: _showAdminDialog,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Вийти з акаунта',
            onPressed: _logout,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.network(
              AppDataStorage.headerImageUrl,
              height: 180,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                height: 180,
                color: Colors.blue.shade100,
                child: const Center(child: Icon(Icons.image, size: 50, color: Colors.blue)),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Оберіть дисципліну для тестування:',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          ...AppDataStorage.disciplines.map((disc) => Container(
            margin: const EdgeInsets.only(bottom: 16),
            child: Card(
              elevation: 3,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: InkWell(
                onTap: () => _startTestForDiscipline(disc),
                borderRadius: BorderRadius.circular(12),
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 28,
                        backgroundColor: (disc['color'] as Color).withOpacity(0.15),
                        child: Icon(disc['icon'], color: disc['color'], size: 30),
                      ),
                      const SizedBox(width: 20),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              disc['title'],
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              disc['subtitle'],
                              style: const TextStyle(color: Colors.grey, fontSize: 13),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Питань у базі: ${(disc['questions'] as List).length}',
                              style: TextStyle(color: Colors.blue.shade700, fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                    ],
                  ),
                ),
              ),
            ),
          )),
          const SizedBox(height: 24),
          const Divider(thickness: 15, color: Color(0xFFF0F0F0)),
          const SizedBox(height: 12),
          const Text(
            'Нормативна база та література',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              leading: const Icon(Icons.menu_book, color: Colors.indigo, size: 36),
              title: const Text('Основна навчальна література та посібники ЄДКІ'),
              subtitle: const Text('Правила ядерної безпеки, підручники з фізики реакторів.'),
              trailing: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const LibraryScreen()),
                  );
                },
                child: const Text('Переглянути'),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== АДМІН-ПАНЕЛЬ КЕРУВАННЯ ====================
class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({Key? key}) : super(key: key);

  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  final TextEditingController _imageController = TextEditingController(text: AppDataStorage.headerImageUrl);

  void _uploadTestFileForDiscipline(int index) async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx', 'docx', 'pdf'],
    );
    
    if (result != null && result.files.single.bytes != null) {
      String fileName = result.files.single.name.toLowerCase();
      try {
        List<Question> loaded = [];
        if (fileName.endsWith('.xlsx')) {
          loaded = await ExamParser.parseExcelBytes(result.files.single.bytes!);
        } else {
          loaded = await ExamParser.parseDocumentBytes(result.files.single.bytes!, fileName);
        }

        setState(() {
          AppDataStorage.disciplines[index]['questions'] = loaded;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Успішно опрацьовано файл: завантажено ${loaded.length} питань!')),
        );
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Помилка обробки файлу: $e')),
        );
      }
    }
  }

  void _changeHeaderImageDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Змінити зображення головного екрана'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _imageController,
              decoration: const InputDecoration(
                labelText: 'Введіть URL зображення',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Скасувати')),
          ElevatedButton(
            onPressed: () {
              setState(() {
                AppDataStorage.headerImageUrl = _imageController.text.trim();
              });
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Зображення головного екрана оновлено!')),
              );
            },
            child: const Text('Зберегти URL'),
          ),
        ],
      ),
    );
  }

  void _editDisciplineTitle(int index) {
    final controller = TextEditingController(text: AppDataStorage.disciplines[index]['title']);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Змінити назву дисципліни'),
        content: TextField(
          controller: controller,
          decoration: const InputDecoration(labelText: 'Нова назва', border: OutlineInputBorder()),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Скасувати')),
          ElevatedButton(
            onPressed: () {
              setState(() {
                AppDataStorage.disciplines[index]['title'] = controller.text;
              });
              Navigator.pop(context);
            },
            child: const Text('Зберегти'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Адмін-панель: Керування контентом')),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text('Керування головним екраном', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.network(
                      AppDataStorage.headerImageUrl,
                      height: 120,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white),
                    onPressed: _changeHeaderImageDialog,
                    icon: const Icon(Icons.edit),
                    label: const Text('Змінити картинку головного екрана'),
                  ),
                ],
              ),
            ),
          ),
          const Divider(height: 40, thickness: 2),
          const Text('Керування дисциплінами та базами тестів', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...List.generate(AppDataStorage.disciplines.length, (index) {
            final disc = AppDataStorage.disciplines[index];
            return Card(
              elevation: 2,
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                title: Text(disc['title'], style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: Text('Питань у базі: ${(disc['questions'] as List).length}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      tooltip: 'Змінити назву',
                      onPressed: () => _editDisciplineTitle(index),
                    ),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                      onPressed: () => _uploadTestFileForDiscipline(index),
                      icon: const Icon(Icons.upload_file, size: 16),
                      label: const Text('Файл тестів'),
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ==================== ЕКРАН БІБЛІОТЕКИ ====================
class LibraryScreen extends StatelessWidget {
  const LibraryScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> books = [
      {'title': 'Основний підручник з ядерної енергетики', 'description': 'Фізика реакторів, розрахунки та методики.'},
      {'title': 'Правила ядерної безпеки АЕС', 'description': 'Офіційний збірник інструкцій Держатомрегулювання.'},
      {'title': 'Теплогідравлічні процеси на енергоблоках', 'description': 'Навчальний посібник для студентів спеціальності 143.'},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Література та нормативи')),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: books.length,
        itemBuilder: (context, index) {
          final book = books[index];
          return Card(
            elevation: 2,
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: const Icon(Icons.book, color: Colors.blue, size: 40),
              title: Text(book['title'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(book['description'] ?? ''),
            ),
          );
        },
      ),
    );
  }
}

// ==================== ЕКРАН ТЕСТУВАННЯ ====================
class ActiveExamPage extends StatefulWidget {
  final String disciplineTitle;
  final List<Question> questions;

  const ActiveExamPage({Key? key, required this.disciplineTitle, required this.questions}) : super(key: key);

  @override
  State<ActiveExamPage> createState() => _ActiveExamPageState();
}

class _ActiveExamPageState extends State<ActiveExamPage> {
  int _currentIndex = 0;
  int? _selectedOptionIndex;
  bool _showExplanation = false;
  int _score = 0;
  final Map<int, int> _userAnswers = {};

  void _answerQuestion(int index) {
    setState(() {
      _selectedOptionIndex = index;
      _userAnswers[_currentIndex] = index;
      if (index == widget.questions[_currentIndex].correctAnswerIndex) {
        _score++;
      }
    });
  }

  void _nextQuestion() {
    if (_currentIndex < widget.questions.length - 1) {
      setState(() {
        _currentIndex++;
        _selectedOptionIndex = _userAnswers[_currentIndex];
        _showExplanation = false;
      });
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) => ExamResultPage(score: _score, total: widget.questions.length),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentQ = widget.questions[_currentIndex];
    final isAnswered = _selectedOptionIndex != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.disciplineTitle, style: const TextStyle(fontSize: 16)),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(value: (_currentIndex + 1) / widget.questions.length),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Питання ${_currentIndex + 1} з ${widget.questions.length}', style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text(currentQ.text, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            ...List.generate(currentQ.options.length, (index) {
              Color btnColor = Colors.white;
              Color textColor = Colors.black;

              if (isAnswered) {
                if (index == currentQ.correctAnswerIndex) {
                  btnColor = Colors.green.shade100;
                  textColor = Colors.green.shade900;
                } else if (index == _selectedOptionIndex) {
                  btnColor = Colors.red.shade100;
                  textColor = Colors.red.shade900;
                }
              }

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: btnColor,
                    foregroundColor: textColor,
                    alignment: Alignment.centerLeft,
                    padding: const EdgeInsets.all(16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  onPressed: isAnswered ? null : () => _answerQuestion(index),
                  child: Text(currentQ.options[index], style: const TextStyle(fontSize: 16)),
                ),
              );
            }),
            const Spacer(),
            if (isAnswered && currentQ.explanation != null) ...[
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.amber.shade100, foregroundColor: Colors.black87),
                onPressed: () => setState(() => _showExplanation = !_showExplanation),
                icon: const Icon(Icons.lightbulb),
                label: Text(_showExplanation ? 'Сховати пояснення' : 'Показати пояснення'),
              ),
              if (_showExplanation) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.amber.shade50, border: Border.all(color: Colors.amber), borderRadius: BorderRadius.circular(8)),
                  child: Text(currentQ.explanation!, style: const TextStyle(fontSize: 14)),
                ),
              ],
            ],
            const SizedBox(height: 16),
            if (isAnswered)
              ElevatedButton(
                style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(50), backgroundColor: Colors.blue, foregroundColor: Colors.white),
                onPressed: _nextQuestion,
                child: Text(_currentIndex == widget.questions.length - 1 ? 'Завершити тест' : 'Наступне питання'),
              ),
          ],
        ),
      ),
    );
  }
}

// ==================== ЕКРАН РЕЗУЛЬТАТІВ ====================
class ExamResultPage extends StatelessWidget {
  final int score;
  final int total;

  const ExamResultPage({Key? key, required this.score, required this.total}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final percentage = (score / total) * 100;

    return Scaffold(
      appBar: AppBar(title: const Text('Результати тестування')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.emoji_events, size: 80, color: Colors.amber),
            const SizedBox(height: 16),
            Text('Ваш результат: $score з $total', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Процент правильних відповідей: ${percentage.toStringAsFixed(1)}%', style: const TextStyle(fontSize: 18, color: Colors.grey)),
            const SizedBox(height: 32),
            ElevatedButton(
              style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(50), backgroundColor: Colors.blue, foregroundColor: Colors.white),
              onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
              child: const Text('Повернутися до вибору дисциплін'),
            ),
          ],
        ),
      ),
    );
  }
}