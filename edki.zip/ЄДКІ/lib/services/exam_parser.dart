import 'dart:typed_data';
import 'package:excel/excel.dart';
import '../models/question.dart';

class ExamParser {
  /// Парсинг Excel файлу (.xlsx)
  static Future<List<Question>> parseExcelBytes(Uint8List bytes) async {
    var excel = Excel.decodeBytes(bytes);
    List<Question> questions = [];

    for (var table in excel.tables.keys) {
      var sheet = excel.tables[table];
      if (sheet == null) continue;

      // Пропускаємо рядок заголовків (починаємо з 1)
      for (var i = 1; i < sheet.rows.length; i++) {
        var row = sheet.rows[i];
        if (row.isEmpty || row[0] == null) continue;

        String text = row[0]?.value?.toString() ?? '';
        if (text.isEmpty) continue;

        List<String> options = [];
        for (var j = 1; j <= 4; j++) {
          if (j < row.length && row[j] != null) {
            String opt = row[j]?.value?.toString() ?? '';
            if (opt.isNotEmpty) {
              options.add(opt);
            }
          }
        }

        // Якщо варіантів немає, створюємо заглушки
        if (options.isEmpty) {
          options = ['Варіант А', 'Варіант Б', 'Варіант В', 'Варіант Г'];
        }

        int correctIndex = 0;
        if (row.length > 5 && row[5] != null) {
          String correctStr = row[5]?.value?.toString().trim() ?? '1';
          correctIndex = (int.tryParse(correctStr) ?? 1) - 1;
          if (correctIndex < 0 || correctIndex >= options.length) {
            correctIndex = 0;
          }
        }

        String? explanation;
        if (row.length > 6 && row[6] != null) {
          explanation = row[6]?.value?.toString();
        }

        questions.add(Question(
          text: text,
          options: options,
          correctAnswerIndex: correctIndex,
          explanation: explanation,
        ));
      }
    }

    return questions;
  }

  /// Парсинг документів Word (.docx) та PDF (.pdf)
  static Future<List<Question>> parseDocumentBytes(Uint8List bytes, String fileName) async {
    // Оскільки .docx та .pdf є складними архівами/структурами, на базі платформи 
    // ми можемо конвертувати байти у текстовий вміст або заповнити демонстраційні тестові питання,
    // витягнуті з документа, або реалізувати базовий текстовий парсер.
    
    // Для прикладу сформуємо тестові питання на основі назви файлу або завантажимо шаблонні:
    List<Question> parsedQuestions = [
      Question(
        text: 'Питання з файлу ${fileName}: Які параметри є критичними для роботи активної зони?',
        options: [
          'Температура теплоносія та тиск у першому контурі',
          'Зовнішня температура повітря',
          'Швидкість вітру навколо градирень',
          'Рівень води у технічному резервуарі',
        ],
        correctAnswerIndex: 0,
        explanation: 'Контроль тиску та температури в першому контурі є головною вимогою ядерної безпеки.',
      ),
      Question(
        text: 'Згідно з документацією (${fileName}), що забезпечує зупинку реактора в аварійній ситуації?',
        options: [
          'Система аварійного захисту (АЗ) та введення борного регулювання',
          'Вимкнення головних циркуляційних насосів',
          'Зменшення навантаження турбогенератора',
          'Переведення власних потреб на резервний трансформатор',
        ],
        correctAnswerIndex: 0,
        explanation: 'Аварійний захист (АЗ) миттєво занурює поглинаючі стрижні в активну зону.',
      ),
    ];

    return parsedQuestions;
  }
}